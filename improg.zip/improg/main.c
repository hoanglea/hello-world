#include <stdio.h>

//int main(){
//  int numbers[5],i;
//  numbers[0] = 20;
//  numbers[1] = 1;
//  numbers[2] = 14;
//  numbers[3] = 41;
//  numbers[4] = 11;
//
//  for(i=0; i<5; i++)
//  {
//      for(int j=0;j<5;j++)
//     {
//         int help;
//         if (numbers[j]>numbers[j+1]){help =numbers[j]; numbers[j]= numbers[j+1]; numbers[j+1]= help; }
//printf("%d\n", numbers[j]);
//  }}
//
//return 0;
//}



//struct  fullname
//{
//
//char lastname[50], midname[50],name[50];
//};
//int main(){
//struct fullname myfullname = {"Le","Anh","Hoang"};
//printf("%s %s %s", myfullname.lastname,myfullname.midname ,myfullname.name);
//
//}
//

//struct Point
//{
//    int x,y;
//};
//int main()
//{
//    struct Point *myPoint = malloc(sizeof(*myPoint));
//    myPoint -> x=10;
//     myPoint -> y=20;
//     printf("x = %d, y = %d", myPoint -> x, myPoint -> y);
//
//}

#include <stdlib.h>
#include <string.h>

struct Person
{
  char * name;
  int yearborn;
  struct Person *next;
};

int main(){
  struct Person *head = NULL;
  int i;

  for (i=0; i<5; i++)
  {
	struct Person *newPerson = malloc(sizeof(*newPerson));
	newPerson -> name = strdup("Josh");
	newPerson -> yearborn = i;
	newPerson -> next = head;
	head = newPerson;
  }


  struct Person *taken_person;
  taken_person = head;
  while (taken_person->next != NULL)
  {

	printf("%d\n", taken_person->yearborn);
	taken_person = taken_person->next;
  }
printf("%d\n", taken_person->yearborn);

  int variable = 6;
}
